

CREATE   TRIGGER battleIDCheck
ON Battle
FOR INSERT AS
DECLARE @TrainerID1 INT
DECLARE @TrainerID2 INT

BEGIN

SET @TrainerID1 = (Select TrainerID1 FROM inserted)
SET @TrainerID2 = (Select TrainerID2 FROM inserted)

	IF (@TrainerID1 = @TrainerID2)
		RAISERROR (N'%*.*s>>',10,1,50,3,N'Trainer IDs cannot be the same!'); 
END
go

