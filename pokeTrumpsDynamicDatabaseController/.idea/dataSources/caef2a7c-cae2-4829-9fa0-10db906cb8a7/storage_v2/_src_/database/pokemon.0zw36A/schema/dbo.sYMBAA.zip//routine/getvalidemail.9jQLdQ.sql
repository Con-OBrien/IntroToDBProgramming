

CREATE   PROCEDURE [dbo].[getValidEmail] @Email varchar(50)
AS
BEGIN
	IF (SELECT COUNT(Email) FROM Trainer WHERE Email = @Email) != 0
		RAISERROR (N'%*.*s>>',10,1,50,3,N'Invalid email address, email already exists!'); 
END
go

