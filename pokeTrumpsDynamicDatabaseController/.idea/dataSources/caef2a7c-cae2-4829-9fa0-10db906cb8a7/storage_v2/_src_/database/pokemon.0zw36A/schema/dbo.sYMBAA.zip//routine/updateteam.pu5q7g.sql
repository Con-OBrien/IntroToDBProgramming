

CREATE   PROCEDURE [dbo].[updateTeam] @TrainerID smallint, @PokemonOff smallint, @PokemonOn smallint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
	IF (SELECT COUNT(TrainerID) FROM TrainerPokemon WHERE TrainerID =@TrainerID AND Team=1) =5
	UPDATE TrainerPokemon SET Team = 0 WHERE PokemonID = @PokemonOff AND TrainerID = @TrainerID;    
	
	IF (SELECT COUNT(TrainerID) FROM TrainerPokemon WHERE TrainerID =@TrainerID AND Team=1) <5
	UPDATE TrainerPokemon SET Team = 1 WHERE PokemonID = @PokemonOn AND TrainerID = @TrainerID;  
		

END
go

