
CREATE VIEW [dbo].[View_InsertPokemon]
AS
SELECT       PokemonID, Name, Attack, Defence, SpecialAttack, SpecialDefence, Speed
FROM            dbo.Pokemon
go

