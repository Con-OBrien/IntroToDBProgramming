
CREATE    VIEW [dbo].[view_pokemon] AS
SELECT PokemonID,Name, Attack, Defence, SpecialAttack, SpecialDefence, Speed 
FROM Pokemon;
go

