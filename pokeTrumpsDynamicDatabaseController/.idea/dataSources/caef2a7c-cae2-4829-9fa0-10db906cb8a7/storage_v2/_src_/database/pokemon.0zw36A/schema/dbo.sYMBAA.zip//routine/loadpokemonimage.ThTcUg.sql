
CREATE   PROCEDURE [dbo].[LoadPokemonImage] 
	-- Add the parameters for the stored procedure here
	@PokemonName  NVARCHAR(200) 
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @fileName NVARCHAR(MAX)
	DECLARE @sql NVARCHAR(MAX)
	PRINT 'Stored Proc '
	SET @fileName = 'C:\pokemon\main-sprites\firered-leafgreen\' + @PokemonName + '.png'
    -- Insert statements for procedure here
	SET @sql ='UPDATE [dbo].[Pokemon] SET [Image] = (SELECT BulkColumn FROM OPENROWSET (BULK N'''+ @fileName+ ''' , SINGLE_BLOB) as x) WHERE [Name] = ''' + @PokemonName +'''' 
	PRINT (@sql)
	EXEC (@sql)

END
go

