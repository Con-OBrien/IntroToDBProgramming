
CREATE   TRIGGER trainerNameCheck
 ON Trainer
FOR INSERT AS 
     DECLARE @valid bit 
	 DECLARE @name varchar(max)
	 
BEGIN  
	SET @name = (Select TName FROM inserted)		
	SET @valid = 0 

     IF @name IS NOT NULL   
        IF len(@name)>3 
			AND len(@name)<21  
			 AND PATINDEX('%[0-9a-zA-Z]%', @name) >0    
               SET @valid=1  
		ELSE
			PRINT 'Username is not valid!'
	ELSE
		PRINT 'Username is Null!';

END
go

