

CREATE    PROCEDURE [dbo].[insertRoundWinner] @BattleID INT, @WinnerID INT
AS
BEGIN
UPDATE dbo.Round
SET WinnerID = @WinnerID
WHERE BattleID = @BattleID
AND RoundID = (SELECT MAX(RoundID) FROM dbo.Round)

END
go

