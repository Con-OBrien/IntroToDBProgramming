

CREATE   PROCEDURE [dbo].[getValidTName] @TName varchar(50)
AS
BEGIN
	IF (SELECT COUNT(TName) FROM Trainer WHERE TName = @TName) != 0
		RAISERROR (N'%*.*s>>',10,1,50,3,N'Invalid trainer name, trainer name already exists!'); 
END
go

