

CREATE   PROCEDURE [dbo].[initiateBattle] @TrainerID1 smallint, @TrainerID2 smallint, @BattleID smallint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	

	DECLARE @Trainer1Score  INT;
	SET @Trainer1Score = 0;

	DECLARE @Trainer2Score  INT;
	SET @Trainer2Score = 0;

    DECLARE @Coin BIT;
	SET @Coin = 0;
	EXEC @Coin = dbo.flipCoin
	
	DECLARE @TempTrainer INT = @TrainerID1;
	
	IF (@Coin = 1)
	BEGIN
		SET @TRAINERID1 = @TRAINERID2;
		SET @TRAINERID2 = @TempTrainer;
	END

	DECLARE  Team1Cursor CURSOR FOR SELECT PokemonID FROM TrainerPokemon WHERE TrainerID = @TrainerID1 AND Team = 1;

	DECLARE  Team2Cursor CURSOR FOR SELECT PokemonID FROM TrainerPokemon WHERE TrainerID = @TrainerID2 AND Team = 1;

	DECLARE @Pokemon1ID  smallint;
	DECLARE @Pokemon2ID  smallint;

	OPEN Team1Cursor
	FETCH NEXT FROM Team1Cursor INTO @Pokemon1ID

	OPEN Team2Cursor
	FETCH NEXT FROM Team2Cursor INTO @Pokemon2ID

	INSERT INTO Battle VALUES(@BattleID, @TrainerID1, @TrainerID2, GETDATE())

	WHILE (@Trainer1Score < 3 AND @Trainer2Score <3 )
	BEGIN 

	EXEC dbo.initiateRound @TrainerID1, @TrainerID2, @BattleID, @Pokemon1ID, @Pokemon2ID
	
	FETCH NEXT FROM Team1Cursor INTO @Pokemon1ID
	FETCH NEXT FROM Team2Cursor INTO @Pokemon2ID
	
	SET @Trainer1Score = (SELECT COUNT(RoundID) From Round where WinnerID = @TrainerID1 AND BattleID = @BattleID)
	SET @Trainer2Score = (SELECT COUNT(RoundID) From Round where WinnerID = @TrainerID2 AND BattleID = @BattleID)

	SET @TempTrainer = @TrainerID1;
	SET @TRAINERID1 = @TRAINERID2;
	SET @TRAINERID2 = @TempTrainer;	
	

	END
	
	IF (@Trainer1Score=3)
	EXEC dbo.getNewPokemon @TrainerID2

	ELSE
	EXEC dbo.getNewPokemon @TrainerID1

	CLOSE Team1Cursor
	DEALLOCATE Team1Cursor

	CLOSE Team2Cursor
	DEALLOCATE Team2Cursor


END

/****** Object:  StoredProcedure [dbo].[insertRoundWinner]    Script Date: 15/11/2018 18:35:56 ******/
SET ANSI_NULLS ON
go

