
CREATE   VIEW [dbo].[view_pokemonNEW] AS
SELECT PokemonID,Name, Attack, Defence, SpecialAttack, SpecialDefence, Speed 
FROM Pokemon;
go

