
CREATE   TRIGGER trainerPasswordCheck
 ON Trainer
FOR INSERT AS 
     DECLARE @valid bit 
	 DECLARE @password varchar(max)
	 
BEGIN  
	SET @password = (Select Password FROM inserted)		
	SET @valid = 0 

     IF @password IS NOT NULL   
        IF len(@password)>5
			AND len(@password)<16	  
			 AND PATINDEX('%[0-9a-zA-Z,.?!]%', @password) > 0 
               SET @valid=1  
		ELSE
			PRINT 'Password is not valid!'
	ELSE
		PRINT 'Password is Null!';

  
END

/****** Object:  Trigger [dbo].[trainerEmailCheck]    Script Date: 08/11/2018 14:53:23 ******/

SET ANSI_NULLS ON
go

