
CREATE   PROCEDURE [dbo].[addFavourate] @TrainerID smallint, @PokemonId smallint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
	IF (SELECT COUNT(TrainerID) FROM TrainerPokemon WHERE TrainerID =@TrainerID AND Favourite=1) <3
	UPDATE TrainerPokemon SET Favourite = 1 WHERE PokemonID = @PokemonID AND TrainerID = @TrainerID;    

END
go

