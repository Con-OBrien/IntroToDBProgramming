

CREATE   PROCEDURE [dbo].[removeFavourate] @TrainerID smallint, @PokemonId smallint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
	UPDATE TrainerPokemon SET Favourite = 0 WHERE PokemonID = @PokemonID AND TrainerID = @TrainerID;    

END
go

