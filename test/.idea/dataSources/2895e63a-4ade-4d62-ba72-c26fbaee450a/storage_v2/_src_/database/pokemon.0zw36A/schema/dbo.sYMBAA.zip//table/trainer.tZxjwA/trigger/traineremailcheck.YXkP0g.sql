
CREATE   TRIGGER trainerEmailCheck
 ON Trainer
FOR INSERT AS 
     DECLARE @valid bit 
	 DECLARE @email varchar(max)
	 
BEGIN  
	SET @email = (Select Email FROM inserted)		
	SET @valid = 0 

     IF @email IS NOT NULL   
        IF @email like '[a-z,0-9,_,-]%@[a-z,0-9,_,-]%.[a-z][a-z]%'  
			 AND @email NOT like '%@%@%'  
             AND CHARINDEX('.@',@email) = 0  
             AND CHARINDEX('..',@email) = 0  
             AND CHARINDEX(',',@email) = 0  
             AND RIGHT(@email,1) between 'a' AND 'z'  
               SET @valid=1  
		ELSE
			PRINT 'Email is not valid!'
	ELSE
		PRINT 'Email is Null!';

END

/****** Object:  Trigger [dbo].[insertBulkImage]    Script Date: 08/11/2018 14:53:23 ******/

SET ANSI_NULLS ON
go

