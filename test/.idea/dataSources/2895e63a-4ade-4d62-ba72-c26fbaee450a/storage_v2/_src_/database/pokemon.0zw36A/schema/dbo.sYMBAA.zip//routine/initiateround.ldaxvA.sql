

CREATE   PROCEDURE [dbo].[initiateRound] @TrainerID1 smallint, @TrainerID2 smallint, @BattleID smallint, @Pokemon1ID smallint, @Pokemon2ID smallint
AS
BEGIN

	DECLARE @RoundID smallint
	DECLARE @Stat nvarchar(MAX)
	DECLARE @RandStat INT
	 
	SET @RandStat = 5*RAND();
	
	SET @Stat =
		CASE @RandStat
			WHEN 1 THEN 'Attack'
			WHEN 2 THEN	'Defence'
			WHEN 3 THEN 'SpecialAttack'
			WHEN 4 THEN 'SpecialDefence'
			ELSE  'Speed'
		END
	
	DECLARE @Trainer1Stat  INT;
	EXEC @Trainer1Stat = dbo.getStatChosen @StatChosen= @Stat, @Trainer2PokemonID =@Pokemon1ID;

	DECLARE @Trainer2Stat  INT;	
	EXEC @Trainer2Stat = dbo.getEnemyStat @StatChosen= @Stat, @Trainer2PokemonID =@Pokemon2ID;

	DECLARE @Winner INT;
	EXEC @Winner = dbo.getRoundWinner @Trainer1Stat, @Trainer2Stat, @TrainerID1, @TrainerID2;

	SET @RoundID = (SELECT MAX(RoundID)FROM Round)+1
	

	INSERT INTO round VALUES (@RoundID, @BattleID, @Pokemon1ID, @Pokemon2ID, 0, @Stat, @Winner);
	
	
END



/****** Object:  StoredProcedure [dbo].[initiateBattle]    Script Date: 15/11/2018 20:27:08 ******/
SET ANSI_NULLS ON
go

