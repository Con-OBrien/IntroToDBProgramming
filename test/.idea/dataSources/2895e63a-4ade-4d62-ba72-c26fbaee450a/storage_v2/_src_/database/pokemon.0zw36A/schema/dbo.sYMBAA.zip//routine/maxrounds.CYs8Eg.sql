
CREATE   PROCEDURE [dbo].[maxRounds]
@BattleID INT
AS 
BEGIN
	IF (SELECT COUNT(RoundID) FROM Round WHERE 
	BattleID=@BattleID) <= 5
	RAISERROR (N'%*.*s>>',10,1,50,3,N'Game is over');
END
go

