

CREATE   PROCEDURE [dbo].[getNewPokemon] @TrainerID smallint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	

	DECLARE @RandPoke INT = 82;
	SET @RandPoke = 82*RAND();


	IF (SELECT COUNT(TrainerID) FROM TrainerPokemon WHERE TrainerID =@TrainerID) =82
			RETURN
            
    ELSE
	WHILE (Select TrainerID from dbo.TrainerPokemon WHERE TrainerID = @TrainerID And PokemonID =@RandPoke) != 0 
		BEGIN
        SET @RandPoke =82*RAND();
        END

		INSERT INTO TrainerPokemon VALUES(@RandPoke, @TrainerID, 0, 0);  
     
     
	 EXEC dbo.updateTeam @TrainerID = @TrainerID, @PokemonOff = 0, @PokemonOn = @RandPoke
	    
		 RETURN

END
go

