CREATE   PROCEDURE [dbo].[getEnemyStat] @statchosen nvarchar(15), @Trainer2PokemonID smallint
AS
BEGIN

DECLARE @STAT smallint
	
IF (@statchosen = 'Attack')  
BEGIN     
	SET @STAT = (SELECT Defence FROM dbo.Pokemon WHERE PokemonID = @Trainer2PokemonID)
END

ELSE IF (@StatChosen = 'Defence')
BEGIN
	SET @STAT = (SELECT Attack FROM dbo.Pokemon WHERE PokemonID = @Trainer2PokemonID)
END

ELSE IF (@StatChosen = 'SpecialAttack')
BEGIN
	SET @STAT = (SELECT SpecialDefence FROM dbo.Pokemon WHERE PokemonID = @Trainer2PokemonID)
END

ELSE IF (@StatChosen = 'SpecialDefence')
BEGIN
	SET @STAT = (SELECT SpecialAttack FROM dbo.Pokemon WHERE PokemonID = @Trainer2PokemonID)
END

ELSE  
BEGIN
    SET @STAT = (SELECT Speed FROM dbo.Pokemon WHERE PokemonID = @Trainer2PokemonID)
END
RETURN @STAT

END
/****** Object:  StoredProcedure [dbo].[getValidEmail]    Script Date: 14/11/2018 19:02:25 ******/
SET ANSI_NULLS ON
go

