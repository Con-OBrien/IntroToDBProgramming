

CREATE    PROCEDURE [dbo].[checkBattleWinner] @TrainerID smallint, @BattleID smallint
AS
DECLARE @Count INT
BEGIN

SET @Count = (SELECT COUNT(RoundID) From Round where WinnerID = @TrainerID AND BattleID = @BattleID)

RETURN @Count
END

/****** Object:  StoredProcedure [dbo].[checkFivePokemon]    Script Date: 14/11/2018 19:02:25 ******/
SET ANSI_NULLS ON
go

