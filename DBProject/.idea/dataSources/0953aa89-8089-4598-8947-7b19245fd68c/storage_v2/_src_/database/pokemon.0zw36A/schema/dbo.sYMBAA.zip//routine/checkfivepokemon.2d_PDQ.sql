
CREATE   PROCEDURE [dbo].[checkFivePokemon]
@trainerID INT
AS 
BEGIN
	IF (SELECT COUNT(PokemonID) FROM TrainerPokemon WHERE 
	TrainerID=@trainerID) != 5
	RAISERROR (N'%*.*s>>',10,1,50,3,N'Must have 5 Pokemon!');
END
go

