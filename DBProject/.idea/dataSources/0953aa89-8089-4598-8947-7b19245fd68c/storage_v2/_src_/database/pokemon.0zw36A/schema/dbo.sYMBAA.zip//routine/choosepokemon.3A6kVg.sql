

CREATE    PROCEDURE [dbo].[choosePokemon] @TrainerID smallint
AS
BEGIN

EXEC dbo.retrieveTeam @TrainerID= @TrainerID;	

RETURN 1;

	
END
go

