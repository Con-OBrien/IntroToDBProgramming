
CREATE   VIEW [dbo].[view_Trainer1WinCheck] AS
SELECT COUNT(r.WinnerID)Rounds_Won
FROM Battle b JOIN Round r ON b.BattleID = r.BattleID
WHERE r.WinnerID = b.TrainerID1
go

