
CREATE   PROCEDURE [dbo].[maxFavourites]
@trainerID INT
AS 
BEGIN
	IF (SELECT COUNT(Favourite) FROM TrainerPokemon WHERE 
	TrainerID=@trainerID) > 3
	RAISERROR (N'%*.*s>>',10,1,50,3,N'Cannot have more than 3!');
END
go

