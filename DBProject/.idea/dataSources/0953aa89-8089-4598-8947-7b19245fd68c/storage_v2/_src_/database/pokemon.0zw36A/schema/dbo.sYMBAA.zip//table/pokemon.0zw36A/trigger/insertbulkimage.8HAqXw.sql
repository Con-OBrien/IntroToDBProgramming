
CREATE   TRIGGER insertBulkImage  
ON Pokemon  
FOR INSERT AS  
DECLARE @pokemonName NVARCHAR(200)
IF @@ROWCOUNT = 1  
BEGIN  
	SET @pokemonName = (SELECT Name FROM inserted)
	EXEC dbo.LoadPokemonImage @pokemonName   
END  
ELSE  
BEGIN  
	DECLARE  insert_Cursor CURSOR FOR
	SELECT Name FROM inserted AS Names

	OPEN insert_Cursor
	FETCH NEXT FROM insert_Cursor INTO @pokemonName

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.LoadPokemonImage @pokemonName
		FETCH NEXT FROM insert_Cursor INTO @pokemonName
	END
	
	CLOSE insert_Cursor
	DEALLOCATE insert_Cursor
	 
END

go

