
CREATE   VIEW view_round AS

SELECT        BattleID, TrainerPokemonID, Trainer2PokemonID, FirstTrainerID, StatChosen, WinnerID
FROM            dbo.Round

go

