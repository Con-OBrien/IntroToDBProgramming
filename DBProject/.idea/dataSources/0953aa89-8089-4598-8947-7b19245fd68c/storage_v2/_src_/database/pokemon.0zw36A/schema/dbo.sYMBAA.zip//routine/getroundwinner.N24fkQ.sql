
CREATE   PROCEDURE [dbo].[getRoundWinner] @Stat1 smallint, @Stat2 smallint, @Trainer1ID smallint, @Trainer2ID smallint
AS
BEGIN
IF @Stat1 > @Stat2
	RETURN @Trainer1ID
ELSE
	RETURN @Trainer2ID
END


/****** Object:  StoredProcedure [dbo].[getStatChosen]    Script Date: 14/11/2018 19:02:25 ******/
SET ANSI_NULLS ON
go

