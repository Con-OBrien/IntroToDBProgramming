
CREATE   PROCEDURE [dbo].[flipCoin]
AS
DECLARE @Coin INT

BEGIN

SET @Coin = 2*RAND();
PRINT @Coin

RETURN @Coin
END

/****** Object:  StoredProcedure [dbo].[getEnemyStat]    Script Date: 14/11/2018 19:02:25 ******/
SET ANSI_NULLS ON
go

